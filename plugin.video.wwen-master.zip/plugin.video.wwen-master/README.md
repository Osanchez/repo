# plugin.video.wwen
A WWE Network plugin for Kodi

This is a release of a plugin to watch WWE Network content through Kodi. You need an active WWE Network subscription for it to work and it might still have a few bugs but it plays the live stream and plays all VOD content.

NOTE: Make sure to fill in your login information and quality settings in the configuration menu before using or you will see errors.

# Known issues:
* Error when trying to play videos too quickly

# Credits:
* http://sourceforge.net/projects/mlbviewer
* https://github.com/MrTimscampi/plugin.video.wwenetwork
* https://github.com/Yuioup/kodi-mlbmc

# [Donation link](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=586YTWL6PHK6Y)
